<?php

return [
    /****************ONLY CHANGE THIS****************/
    'site_name' => 'MPWA Multi device version',
	'header_side' => 'MPWA v'.config('app.version'),
	'footer_name' => 'MPWA',
	'footer_copyright' => 'Made with ❤️ by Magd',
	/************************************************/
];
