<?php return array (
  'midtrans' => 
  array (
    'status' => 'disable',
    'merchant_id' => 'G12xxxxxx',
    'server_key' => 'SB-Mid-server-xxxxxx',
    'client_key' => 'SB-Mid-client-xxxxxx',
    'is_production' => 'false',
  ),
  'stripe' => 
  array (
    'status' => 'disable',
    'secret_key' => 'sk_xxxxxx',
    'publishable_key' => 'pk_xxxxxx',
    'webhook_secret' => 'whsec_xxxxxx',
  ),
  'paypal' => 
  array (
    'status' => 'disable',
    'client_id' => 'AYmthwTxxxxx',
    'client_secret' => 'EIjkvxxxxx',
    'mode' => 'sandbox',
  ),
  'paymob' => 
  array (
    'status' => 'disable',
    'hmac_key' => 'C49A3DDAxxxxxx',
    'integration_id' => '489xxxxx',
    'secret_key' => 'egy_sk_xxxxxx',
    'public_key' => 'egy_pk_xxxxxx',
  ),
  'nowpayments' => 
  array (
    'status' => 'disable',
    'api_key' => 'K8Q3xxxxx',
    'public_key' => 'd821xxxxx',
    'pay_currency' => 'BTC',
  ),
  'paystack' => 
  array (
    'status' => 'disable',
    'secret_key' => 'sk_xxxxx',
    'public_key' => 'pk_xxxxx',
  ),
  'flutterwave' => 
  array (
    'status' => 'disable',
    'public_key' => 'FLWPUxxxxx',
    'secret_key' => 'FLWSExxxxx',
    'encryption_key' => 'FLWSECxxxxx',
    'payment_options' => 'card,banktransfer,ussd,credit,opay,account,internetbanking,googlepay,enaira',
  ),
  'duitku' => 
  array (
    'status' => 'disable',
    'api_key' => '9e2acxxxxx',
    'merchant_code' => 'DS21395',
    'paymentMethod' => 'VC',
    'is_production' => 'false',
  ),
  'tripay' => 
  array (
    'status' => 'disable',
    'api_key' => 'DEV-xxxxx',
    'private_key' => 'NVsmcxxxxx',
    'merchant_code' => 'T1xxxxx',
    'is_production' => 'false',
  ),
  'xendit' => 
  array (
    'status' => 'disable',
    'secret_key' => 'xnd_xxxxx',
    'public_key' => 'xnd_xxxxx',
  ),
  'geniebiz' => 
  array (
    'status' => 'disable',
    'application_id' => '1c4e3xxxxx',
    'api_key' => 'eyJhxxxxx',
    'is_production' => 'true',
  ),
  'custom' => 
  array (
    'status' => 'disable',
    'title' => 'Bank transfer',
    'html' => 'PHA+TmFtZTogPHNwYW4gc3R5bGU9ImNvbG9yOiByZ2IoMCwgMTAyLCAyMDQpOyI+VG9tIENydWlzZTwvc3Bhbj48L3A+PHA+QmFuayBuYW1lOiA8c3BhbiBzdHlsZT0iY29sb3I6IHJnYigwLCAxMDIsIDIwNCk7Ij5CQ0E8L3NwYW4+PC9wPjxwPklCQU46IDxzcGFuIHN0eWxlPSJjb2xvcjogcmdiKDAsIDEwMiwgMjA0KTsiPjM4ODM0ODczNDg3ODwvc3Bhbj48L3A+PHA+U29mdENvZGU6IDxzcGFuIHN0eWxlPSJjb2xvcjogcmdiKDAsIDEwMiwgMjA0KTsiPklCQ0E4NDM4MzRYWDwvc3Bhbj48L3A+PHA+QWNjb3VudCBObzogPHNwYW4gc3R5bGU9ImNvbG9yOiByZ2IoMCwgMTAyLCAyMDQpOyI+MTExMTExMTExMTE8L3NwYW4+PC9wPjxwPjxicj48L3A+PHA+QWZ0ZXIgdGhlIHRyYW5zZmVyLCBwbGVhc2Ugc2VuZCB0aGUgdHJhbnNmZXIgcmVjZWlwdCB0byB0aGUgZm9sbG93aW5nIGVtYWlsOiBhZG1pbkB5b3Vyc2l0ZS5jb208L3A+PHA+PHNwYW4gc3R5bGU9ImNvbG9yOiByZ2IoMjMwLCAwLCAwKTsiPiogTm90ZTogT25jZSB0aGUgdHJhbnNmZXIgaXMgY29uZmlybWVkLCB5b3VyIHBsYW4gd2lsbCBiZSBhY3RpdmF0ZWQgaW1tZWRpYXRlbHkuPC9zcGFuPjwvcD4=',
  ),
  'fawaterk' =>
  array (
    'status'       => 'disable',
    'api_key'      => '0f953xxxxx',
    'provider_key' => 'FAWxxxxx',
	'mode' => 'live',
  ),
  'phonepe' =>
  array (
    'status'       => 'disable',
    'merchant_id'   => 'PGTExxxxxxxxx',
    'salt_key'      => '9643xxxxxxxxx',
    'salt_index'    => '1',
	'is_production' => 'false',
),

);