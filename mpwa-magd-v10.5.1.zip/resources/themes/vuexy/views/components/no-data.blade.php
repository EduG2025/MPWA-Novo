<tr>
    <td colspan="{{ $colspan ?? '' }}" class="text-center">
        <div class="d-flex flex-column align-items-center">
		<i class="icon-base ti tabler-brand-databricks icon-36px text-primary"></i>
       <h5>{{$text ?? ''}}</h5>
        </div>
    </td>
</tr>